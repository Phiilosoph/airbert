#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <Adafruit_NeoPixel.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_Sensor.h>
#include <DHT.h>
#include <DHT_U.h>
#include "FS.h"
#include "SD.h"
#include "SPI.h"
#include <WiFi.h>
#include <time.h>
#include <Adafruit_BNO055.h>
#include <utility/imumaths.h>

// Wi-Fi 
const char* ssid     = "XXX";
const char* password = "XXX";

// Tiltsensor
Adafruit_BNO055 bno = Adafruit_BNO055(55, 0x28);  // 0x28 is the default I2C address

// DHT11 Sensor
#define DHTPIN 13
#define DHTTYPE DHT11
DHT dht(DHTPIN, DHTTYPE);

// SD Card
#define SD_CS 5
unsigned long lastWrite = 0;
const unsigned long writeInterval = 600000; // 10 minutes

// OLED Display
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define I2C_SDA 21
#define I2C_SCL 22
unsigned long muteUntil = 0;
const unsigned long muteDuration = 10 * 1000UL * 60;  // 10 minutes in milliseconds *60*

// NeoPixel
#define NUM_LEDS 12
#define NEOPIXEL_PIN 4

// Onboard LED
#define STATUS_LED 2

// GYRO
bool tilted = false;

// Gas Sensor
#define MQ135_AO_PIN 34
#define MQ135_DO_PIN 35

// Display and Pixels
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
Adafruit_NeoPixel pixels = Adafruit_NeoPixel(NUM_LEDS, NEOPIXEL_PIN, NEO_GRB + NEO_KHZ800);

void setup() {
  Serial.begin(115200);

  // Wi-Fi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("WiFi connected");

  // NTP time
  configTime(0, 0, "pool.ntp.org");
  struct tm timeinfo;
  while (!getLocalTime(&timeinfo)) {
    Serial.println("Waiting for NTP time...");
    delay(1000);
  }

  dht.begin();

  // SD Card
  if (!SD.begin(SD_CS)) {
    Serial.println("SD card initialization failed!");
    while (1);
  }
  Serial.println("SD card ready.");

  // GPIO
  pinMode(STATUS_LED, OUTPUT);
  pinMode(NEOPIXEL_PIN, OUTPUT);

  // I2C
  Wire.begin(I2C_SDA, I2C_SCL);

  // Gyro
  if (!bno.begin()) {
    Serial.println("Failed to initialize BNO055!");
    while (1);
  }
  delay(1000);  // give it some time to start
  bno.setExtCrystalUse(true);

  // OLED
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 allocation failed"));
    while (true);
  }
  display.clearDisplay();
  display.display();

  // NeoPixel
  pixels.begin();
  pixels.show();
}

void loop() {
  // Read DHT sensor once per loop
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();

  /*if (isnan(temperature) || isnan(humidity)) {
    Serial.println("Failed to read from DHT sensor!");
    return;
  }*/

  unsigned long currentTime = millis();

  // SD logging
  if (currentTime - lastWrite >= writeInterval) {
    struct tm timeinfo;
    if (!getLocalTime(&timeinfo)) {
      Serial.println("Failed to get time");
      return;
    }

    char timestamp[25];
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", &timeinfo);

    String dataString = String(timestamp) + ", ";
    dataString += "Temp: " + String(temperature - 10) + " C, ";
    dataString += "Humidity: " + String(humidity) + " %";

    Serial.println("Writing to file: " + dataString);

    File dataFile = SD.open("/log.txt", FILE_APPEND);
    if (dataFile) {
      dataFile.println(dataString);
      dataFile.close();
      Serial.println("Data written.");
    } else {
      Serial.println("Failed to open log.txt");
    }

    lastWrite = currentTime;
  }

  // Gas sensor
  int GasanalogValue = analogRead(MQ135_AO_PIN);
  int GasdigitalValue = digitalRead(MQ135_DO_PIN);

  // Gyroscope
  imu::Vector<3> euler = bno.getVector(Adafruit_BNO055::VECTOR_EULER);
  float heading = euler.x();   // yaw
  float roll = euler.y();      // roll
  float pitch = euler.z();     // pitch

  // Serial log
  Serial.printf("Temp: %.1f°C  Humidity: %.1f%%\n", temperature - 10, humidity);
  Serial.printf("Gas Analog: %d  Gas Digital: %d\n", GasanalogValue, GasdigitalValue);
  Serial.printf("Orientation -> Heading: %.2f°, Roll: %.2f°, Pitch: %.2f°\n", heading, roll, pitch);

  // OLED update
  display.clearDisplay();
  display.setTextSize(1.5);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.printf("Temp: %.1f C\n", temperature - 10);
  display.printf("Humidity: %.1f %% \n", humidity);
  delay(500);

  if (roll < -10) {
  pixels.setBrightness(64); // Set brightness BEFORE assigning colors
} else {
  pixels.setBrightness(255); // Full brightness otherwise (optional)
}

  if (GasanalogValue < 1000) {
    digitalWrite(STATUS_LED, HIGH);
    for (int i = 0; i < NUM_LEDS; i++) {
      pixels.setPixelColor(i, pixels.Color(0, 255, 0));
    }
    display.printf("Luft: Normal\n");
  } else {
    digitalWrite(STATUS_LED, LOW);

    // Detect tilt condition
    if (pitch < 60 && pitch > 0 && !tilted) {
      tilted = true;
      muteUntil = millis() + muteDuration;
    }

    

    if (tilted && millis() < muteUntil) {
      for (int i = 0; i < NUM_LEDS; i++) {
        pixels.setPixelColor(i, pixels.Color(0, 0, 255));
      }
      display.clearDisplay();
      display.setTextSize(2);
      display.setCursor(0, 0);
      //display.println("Tilt erkannt!");
      display.println("Mute aktiv!");
    } else {
      if (tilted && millis() >= muteUntil) {
        tilted = false;
      }
      for (int i = 0; i < NUM_LEDS; i++) {
        pixels.setPixelColor(i, pixels.Color(255, 0, 0));
      }
      display.clearDisplay();
      display.setTextSize(2);
      display.setCursor(0, 0);
      display.println("Luft:");
      display.println("Kritisch!");
      display.println("Lueften!");
    }
  }

  pixels.show();
  display.display();
}

